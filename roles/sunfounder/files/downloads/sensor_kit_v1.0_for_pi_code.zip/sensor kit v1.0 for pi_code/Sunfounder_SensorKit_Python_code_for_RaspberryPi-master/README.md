## Sunfounder SensorKit Python code for Raspberry Pi

This is Sunfounder sensor kit python code for Raspberry Pi Model B/B+ and Raspberry Pi 2 Model B.
If you have any questions about this kit, please contact with us. Our website is www.sunfounder.com, and our support E-mail is support@sunfounder.com

